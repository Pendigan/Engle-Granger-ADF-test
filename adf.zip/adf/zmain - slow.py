import sys, time, threading, queue
import s_p as sp
import numpy as np
from Results import *
from utils import linear_regression, same_size, read_stocks, create_pairs, ad_fuller, create_non_stationary_pairs


final_results = {}

'''
    Reading the assets files to get the historical OHLCV data out
'''
def get_stocks(assets):
    print('Reading files to get stocks data, please wait...')
    stocks = {}
    for asset in assets:
        filename = sp.stocks_filenames[asset]
        stocks[asset] = read_stocks(filename, asset)
    print('All datas are in')
    return stocks

'''
    Testing all the assets with adfuller and returning those who aren't
'''
def is_stationary(stocks):
    print('ADF Tests started...')
    for i in stocks:
        s = stocks[i]
        stationary, _, _ = ad_fuller(s.closes())
        s.is_stationary = stationary
    return stocks

'''
    Creating n chunk of len(l) / n elements
    (probably not very efficient)
'''
def chunks(l, n):
    pos = 0
    pairs = [[]]
    for i in range(len(l)):
        pairs[pos].append(l[i])
        if i % n == 0 and i != 0:
            pos += 1
            pairs.append([])

    return pairs

def threading_handler(chunked_pairs, thread_n):
    results = {}
    print('Thread {} started to compute {} pairs'.format(thread_n, len(chunked_pairs)))
    for i, el in enumerate(chunked_pairs):
        if el[0] not in results:
            results[el[0]] = {}
        if el[1] not in results:
            results[el[1]] = {}
        c_a = np.array(stocks[el[0]].closes())
        c_b = np.array(stocks[el[1]].closes())

        c_a, c_b = same_size(c_a, c_b)

        lireg_a = linear_regression(c_a, c_b)
        lireg_b = linear_regression(c_b, c_a)

        r1 = (c_a - lireg_a.slope * c_b)
        r2 = (c_b - lireg_b.slope * c_a)

        stationary_a, pvalue_a, adf_a = ad_fuller(r1)
        stationary_b, pvalue_b, adf_b = ad_fuller(r2)

        results[el[0]][el[1]] = Results(adf_a, pvalue_a, stationary_a, lireg_a.slope).summary()
        results[el[1]][el[0]] = Results(adf_b, pvalue_b, stationary_b, lireg_b.slope).summary()

    print('Thread {} finished'.format(thread_n))
    for i in results:
        for j in results[i]:
            final_results[i][j] = results[i][j]
    # return results

if __name__ == "__main__":

    stocks = get_stocks(sp.stocks_filenames)

    stocks = is_stationary(stocks)
    pairs = create_non_stationary_pairs(stocks)

    for i in stocks:
        if not stocks[i].is_stationary:
            final_results[i] = {}

    print(len(pairs), 'pairs to evaluate')
    threads = 30
    pairs_per_threads = len(pairs) // threads
    chunked_pairs = chunks(pairs, pairs_per_threads)

    print('Starting linear regression and ADF tests on non stationary datas. This may take some times...')
    print('{} threads will handle the computation of {} pairs'.format(threads, pairs_per_threads))
    start_time = time.time()

    '''
        Multi-threading preparation and execution
    '''
    threads = []
    que = queue.Queue()

    for i, chunk in enumerate(chunked_pairs):
        threads.append(
            threading.Thread(target=threading_handler, args=(chunk, i))
        )
    for i in threads:
        i.start()
    for i in threads:
        i.join()

    stop_time = time.time()
    print('Total processing time', stop_time-start_time,'s')

    # t_result = []
    # while not que.empty():
    #     t_result.append(que.get())

    print('Computing is finished, printing now')

    # for i in t_result:
    #     for a_a in i:
    #         for a_b in i[a_a]:
    #             final_results[a_a][a_b] = i[a_a][a_b]

    for i in final_results:
        final_results[i][i] = 'empty'
    print(final_results)

    # Building the CSV header
    header = [x for x in final_results]
    header.insert(0, 'stocks_name')

    # Creating each lines of the CSV file
    lines = []
    for i in final_results:
        lines.append(i)
        last = len(lines)-1
        for h in header:
            if h in final_results:
                print(i, h)
                asdf = final_results[i][h]
                lines[last] += ';'+ asdf

    # Writing the content into the CSV file named 'adf.csv'
    f = open('adf.csv', 'w')
    f.write(';'.join(header)+'\n')
    for i in lines:
        f.write(i + '\n')
    f.close()

    print('Bye !')