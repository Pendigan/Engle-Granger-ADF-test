from s_p import s_and_p
from asset import Asset, OHLCV, ADF_Test
from statsmodels.tsa.stattools import adfuller
from scipy import stats
import itertools as cn

import time

def create_pairs():
    pairs = []
    for first in s_and_p:
        for second in s_and_p:
            pairs.append([first, second])
    return pairs

def create_non_stationary_pairs(stocks):
    non_stationary = [stocks[i].name for i in stocks if not stocks[i].is_stationary]
    print(len(non_stationary), 'non stationary assets out of', len(s_and_p))
    pairs = []
    comb = cn.combinations(non_stationary, 2)
    for i in comb:
        pairs.append(i)

    return pairs

def convert_date(date):
    return int(time.mktime(time.strptime(date, '%Y-%m-%d')))

def read_stocks(filename, asset_name):
    file = open(filename, 'r')
    asset = Asset(asset_name)
    for i, line in enumerate(file.readlines()):
        line = line.replace('\n', '').split(',')
        if i != 0:
            d = OHLCV(line)
            asset.add_time(line[0], d)
    file.close()
    return asset


# return : is_stationary, pvalue, adf-test
def ad_fuller(close_times, printResults = True, significance=.05):
    SignificanceLevel = significance
    pValue = None
    is_stationary = False

    adfTest = adfuller(close_times, autolag='AIC')
    # print('adf:', adf)
    pValue = adfTest[1]
    adf_value = adfTest[0]

    if (pValue < SignificanceLevel):
        is_stationary = True

    return is_stationary, pValue, adf_value

def same_size(serie_a, serie_b):
    len_a = len(serie_a)
    len_b = len(serie_b)
    r_a = serie_a
    r_b = serie_b

    if len_a > len_b:
        r_a = r_a[-len_b:]
    if len_b > len_a:
        r_b = r_b[-len_a:]

    return (r_a, r_b)

class LinearRegression:
    def __init__(self, slope, intercept, r, p, std_err):
        self.slope = slope
        self.intercept = intercept
        self.r = r
        self.p = p
        self.std_err = std_err

# return : LinearRegression(slope, intercept, r, p, std_err)
def linear_regression(serie_a: list, serie_b: list):
    slope, intercept, r, p, std_err = stats.linregress(serie_a, serie_b)
    return LinearRegression(slope, intercept, r, p, std_err)