class Results:
    def __init__(self, adf, pvalue, stationary: bool, beta):
        self.adf = adf
        self.pvalue = pvalue
        self.stationary = stationary
        self.beta = beta

    def summary(self):
        return '{},{},{},{}'.format(self.adf, self.pvalue,self.stationary,self.beta)