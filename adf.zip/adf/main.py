import sys, time, multiprocessing
import s_p as sp
import numpy as np
from Results import *
from utils import linear_regression, same_size, read_stocks, create_pairs, ad_fuller, create_non_stationary_pairs


final_results = {}

'''
    Reading the assets files to get the historical OHLCV data out
'''
def get_stocks(assets):
    print('Reading files to get stocks data, please wait...')
    stocks = {}
    for asset in assets:
        filename = sp.stocks_filenames[asset]
        stocks[asset] = read_stocks(filename, asset)
    print('All datas are in')
    return stocks

'''
    Testing all the assets with adfuller and returning those who aren't
'''
def is_stationary(stocks):
    print('ADF Tests started...')
    for i in stocks:
        s = stocks[i]
        stationary, _, _ = ad_fuller(s.closes())
        s.is_stationary = stationary
    return stocks

def calculate(params):
    c_a = params[0]
    c_b = params[1]
    pair = params[2]
    results = {}
    results[pair[0]] = {}
    results[pair[1]] = {}

    lireg_a = linear_regression(c_a, c_b)
    lireg_b = linear_regression(c_b, c_a)

    r1 = (c_a - lireg_a.slope * c_b)
    r2 = (c_b - lireg_b.slope * c_a)

    stationary_a, pvalue_a, adf_a = ad_fuller(r1)
    stationary_b, pvalue_b, adf_b = ad_fuller(r2)

    results[pair[0]][pair[1]] = Results(adf_a, pvalue_a, stationary_a, lireg_a.slope).summary()
    results[pair[1]][pair[0]] = Results(adf_b, pvalue_b, stationary_b, lireg_b.slope).summary()
    return results

if __name__ == "__main__":

    stocks = get_stocks(sp.stocks_filenames)

    stocks = is_stationary(stocks)
    pairs = create_non_stationary_pairs(stocks)

    for i in stocks:
        if not stocks[i].is_stationary:
            final_results[i] = {}

    print(len(pairs), 'pairs to evaluate')


    print('Starting linear regression and ADF tests on non stationary datas. This may take some times...')
    start_time = time.time()
    params = []
    for n, pair in enumerate(pairs):
        c_a = np.array(stocks[pair[0]].closes())
        c_b = np.array(stocks[pair[1]].closes())

        c_a, c_b = same_size(c_a, c_b)
        params.append([c_a, c_b, pair])
    q = multiprocessing.Pool(multiprocessing.cpu_count())
    t_results = q.map(calculate, params)

    stop_time = time.time()
    print(t_results)
    print('Total processing time', stop_time-start_time,'s')

    print('Computing is finished, printing')
    for i in t_results:
        for a_a in i:
            for a_b in i[a_a]:
                final_results[a_a][a_b] = i[a_a][a_b]

    for i in final_results:
        final_results[i][i] = 'empty'

    # Building the CSV header
    header = [x for x in final_results]
    header.insert(0, 'stocks_name')

    # Creating each lines of the CSV file
    lines = []
    for i in final_results:
        lines.append(i)
        last = len(lines)-1
        for h in header:
            if h in final_results:
                asdf = final_results[i][h]
                lines[last] += ';'+ asdf

    # Writing the content into the CSV file named 'adf.csv'
    f = open('adf.csv', 'w')
    f.write(';'.join(header)+'\n')
    for i in lines:
        f.write(i + '\n')
    f.close()

    print('Bye !')