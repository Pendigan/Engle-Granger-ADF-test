import time

class Asset:
    def __init__(self, name):
        self.name = name
        self.as_time = {}
        self.closes_data: list = []
        self.timestamp: list = []
        self.is_stationary: bool = False

    def add_time(self, date, ohlcv):
        timestamp = int(time.mktime(time.strptime(date, '%Y-%m-%d')))
        self.timestamp.append(timestamp)
        self.as_time[timestamp] = ohlcv

    def closes(self):
        res = []
        if len(self.closes_data) == 0:
            for t in self.as_time:
                res.append(self.as_time[t].c)
            self.closes_data = res
        return self.closes_data

class OHLCV:
    def __init__(self, data):
        self.o = float(data[1]) if data[1] != '' else 0.0
        self.h = float(data[2]) if data[2] != '' else 0.0
        self.l = float(data[3]) if data[3] != '' else 0.0
        self.c = float(data[4]) if data[4] != '' else print('error on close price', data, data[4]) #; exit()
        self.v = float(data[5]) if data[5] != '' else 0.0

class ADF_Test:
    def __init__(self, adf_test: float, pvalue: float, stationary: bool):
        self.adf_test = adf_test
        self.pvalue = pvalue
        self.stationary = stationary